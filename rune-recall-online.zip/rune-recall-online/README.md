# Rune Recall Online 🎧

A browser-based **Ragnarok Online BGM map guessing game** with real online rooms. One player hosts, sends a six-character room code or invite URL, and everyone else joins on their own phone or computer.

## What this version does

- Create online rooms with a six-character invite code and **Copy invite link** button.
- Up to **12 players** per room, each with their own nickname.
- Real-time lobby, multiple-choice or type-your-answer guessing, reveal screen, scoring, and rematches.
- Host imports **their own** numbered Ragnarok Online BGM files; the app matches 95 classic music entries to representative RO maps.
- The host uploads **only the current round's audio** to the room server, temporarily, so guests can listen without installing RO or importing songs.
- Private guesses until the reveal; correct answer is +100 points.
- Desktop and mobile responsive UI, guest audio replay, and an optional 15–60 second timer.

**Important:** RO BGM is not included. Import music files you are authorized to use. Audio is temporarily transmitted to your hosted server and streamed to players; do not use files that you don't have the right to share.

## Put it online for free (Render + GitHub)

You **must deploy the Node.js server**; uploading just `index.html` to Netlify will not enable online rooms. This is a single project: one Render web service hosts both the website and the live room server.

1. Download and extract the **rune-recall-online.zip** package.
2. Log in to [GitHub](https://github.com/), select **New repository**, name it `rune-recall-online`, and create it. You can choose a public or private repo.
3. In the new repo select **Add file → Upload files**. Drag the *contents* of your extracted project folder into the upload window. **Keep the `public/` folder** with `index.html`, `app.js`, and `styles.css` inside it. Commit the files. (Alternative: `git add . && git commit -m "initial" && git push`.)
4. Go to [Render](https://dashboard.render.com/), select **New → Web Service**, and connect your GitHub repository. Render can also use the included `render.yaml` as a Blueprint.
5. Configure:
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type / Plan:** Free
   - **Health Check Path:** `/health` (if offered)
6. Deploy. Your site will have a URL similar to `https://rune-recall-online.onrender.com` (actual hostname depends on the service name you choose).
7. Open that URL, click **Create a room**, type your nickname, and click **Copy invite link**. Send that link to friends. They can join from their own devices.

Once published, the same website URL can be used to create new rooms whenever you want.

## How to play

1. Host creates room and shares invite link.
2. Each friend opens the link, enters a nickname, and joins the lobby.
3. Host selects **BGM folder** or picks audio files. `08.mp3` maps to Prontera, `11.mp3` to Morroc, `14.mp3` to Payon, etc.
4. Host chooses map pack, number of rounds, difficulty, and timer, then clicks **Start the challenge**.
5. A small song upload happens per round. Guests click **▶** to enable music if their browser blocks automatic audio playback. They hear the same track, choose a map, and lock their own guesses.
6. Answers reveal after everyone guesses or time expires. The host can advance to the next round. Leaderboard updates live.

**If the host refreshes**, the room can reconnect but the browser may require the BGM files to be selected again, because imported files are not permanently stored.

## Run it on your PC (for testing)

Requires [Node.js 20+](https://nodejs.org/). In the extracted folder:

```bash
npm install
npm start
```

Then open `http://localhost:3000` on your PC. Remote friends cannot use `localhost`; deploy to Render to get a public URL.

To run the multiplayer protocol tests:

```bash
npm test
```

No secret API keys, databases, or third-party Node packages are needed.

## Hosting / storage caveats

- Render Free services may sleep when idle and are subject to free-plan limitations; the first visit after inactivity may take longer.
- Rooms, scores, and currently uploaded audio are **temporary** (kept in process memory and temporary disk). **A server restart loses active rooms.** This is a party game, not persistent tournament hosting.
- The host should stay connected while the game is in progress.
- Audio files larger than **20 MB each** are rejected. Only the current round's file is retained on the server.
- Guests are advised to tap the audio play button once, because mobile browsers commonly restrict autoplay.
- Filename-to-map associations are based on the iRO original soundtrack listing; individual RO servers may have different maps/BGMs. Some music is used across multiple maps, so guesses use a representative area.
- Self-host or upgrade the server if you need higher availability, persistent results, or large public rooms.

## Project files

```
server.js             # Node HTTP + WebSocket room server (no dependencies)
tracks.json           # RO BGM ID / map catalog
package.json          # npm start / npm test
render.yaml           # Render Blueprint for a free web service
public/
  index.html          # Responsive UI
  styles.css          # Styling
  app.js              # Client-side multiplayer/audio logic
tests/
  multiplayer.test.js # Automated host+guest multiplayer test
```

Fan-made game, not affiliated with GRAVITY or Ragnarok Online. No copyrighted music is bundled with this project.
