'use strict';
// Rune Recall: one-process realtime multiplayer game + audio relay.
// No account, database, or external API keys required.
const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const {pipeline} = require('node:stream/promises');
// Minimal standards-compatible WebSocket implementation using Node built-ins.
// Browser clients use the native WebSocket API; no third-party server package required.
class WebSocket {
 static OPEN=1;
 constructor(socket){this.socket=socket;this.readyState=1;this.listeners={};this.pending=Buffer.alloc(0);
  socket.on('data',chunk=>this.receive(chunk));socket.on('close',()=>{this.readyState=3;this.emit('close')});socket.on('error',e=>this.emit('error',e));}
 on(type,fn){(this.listeners[type]??=[]).push(fn)}
 emit(type,...args){for(const fn of this.listeners[type]||[])fn(...args)}
 frame(opcode,payload){if(this.readyState!==1)return;let h;if(payload.length<126){h=Buffer.from([0x80|opcode,payload.length])}else if(payload.length<65536){h=Buffer.alloc(4);h[0]=0x80|opcode;h[1]=126;h.writeUInt16BE(payload.length,2)}else{h=Buffer.alloc(10);h[0]=0x80|opcode;h[1]=127;h.writeBigUInt64BE(BigInt(payload.length),2)}this.socket.write(Buffer.concat([h,payload]))}
 send(s){this.frame(1,Buffer.from(s))}
 close(code=1000,reason=''){if(this.readyState!==1)return;const b=Buffer.from(String(reason).slice(0,120));const c=Buffer.alloc(2);c.writeUInt16BE(code);this.frame(8,Buffer.concat([c,b]));this.readyState=2;this.socket.end()}
 receive(chunk){this.pending=Buffer.concat([this.pending,chunk]);while(this.pending.length>=2){const b=this.pending;const fin=(b[0]&128)!==0,op=b[0]&15,masked=(b[1]&128)!==0;let len=b[1]&127,off=2;if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);off=4}else if(len===127){if(b.length<10)return;const big=b.readBigUInt64BE(2);if(big>65536n){this.close(1009,'Message too large');return}len=Number(big);off=10}if(!masked||len>65536){this.close(1002,'Invalid WebSocket frame');return}if(b.length<off+4+len)return;const mask=b.subarray(off,off+4),payload=Buffer.from(b.subarray(off+4,off+4+len));this.pending=b.subarray(off+4+len);for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];if(op===8){this.close();return}if(op===9){this.frame(10,payload);continue}if(op===1&&fin)this.emit('message',payload);else if(op!==10){this.close(1003,'Unsupported frame');return}}}
}
const TRACKS = require('./tracks.json');
const BY_ID = Object.fromEntries(TRACKS.map(t => [t.id, t]));
const PUBLIC = path.join(__dirname,'public');
const TEMP = path.join(os.tmpdir(),'rune-recall-'+process.pid);
fs.mkdirSync(TEMP,{recursive:true});
const rooms = new Map();
const MAX_PLAYERS = 12;
const MAX_UPLOAD = 20*1024*1024;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const PORT = parseInt(process.env.PORT||'3000',10);
const send = (ws,obj)=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));};
function uniqueCode(){let c;do{c=Array.from({length:6},()=>CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)]).join('')}while(rooms.has(c));return c;}
function randomId(){return crypto.randomBytes(16).toString('hex')}
function cleanName(value){return String(value||'').trim().replace(/[\u0000-\u001f]/g,'').slice(0,22)}
function normalize(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,'')}
function canonicalName(s){return String(s||'').normalize('NFKC').toLocaleLowerCase().replace(/\s+/g,' ').trim()}
function correct(answer,track,mode){if(!answer)return false;const a=normalize(answer),c=normalize(track.area);if(a===c)return true;if(mode!=='hard')return false;if(a.length>=4&&((c.includes(a)&&c.length-a.length<=5)||(a.includes(c)&&a.length-c.length<=5)))return true;const special={yuno:'juno',bio:'biolabs',biolab:'biolabs',byalan:'underseatunnel',glastheim:'glastheim',payoncaves:'payoncave'};if(special[a]===c)return true;return track.extra.split(/[,/]/).map(normalize).some(x=>x&&a.length>=5&&(a===x||(x.includes(a)&&x.length-a.length<=4)));}
function randomize(array){const a=[...array];for(let i=a.length-1;i>0;i--){const j=crypto.randomInt(i+1);[a[i],a[j]]=[a[j],a[i]]}return a}
function optionsFor(track){const pool=randomize(TRACKS.filter(t=>t.area!==track.area));const opts=[track.area];for(const t of pool){if(!opts.includes(t.area))opts.push(t.area);if(opts.length===4)break}return randomize(opts)}
function validSettings(raw){return {rounds:[5,10,15,20].includes(+raw?.rounds)?+raw.rounds:10,duration:[15,20,30,45,60].includes(+raw?.duration)?+raw.duration:30,mode:raw?.mode==='hard'?'hard':'choice',pack:['classic','all','cities','fields','dungeons'].includes(raw?.pack)?raw.pack:'classic'};}
function publicState(room,viewer){const phase=room.phase;const track=room.currentTrack;return {code:room.code,isHost:viewer.id===room.hostId,me:viewer.id,phase,settings:room.settings,players:[...room.players.values()].map(p=>({id:p.id,name:p.name,score:p.score,connected:!!p.ws&&p.ws.readyState===WebSocket.OPEN,locked:room.answers.has(p.id)})),roundIndex:room.roundIndex,roundTotal:room.queue.length,round:track?{options:phase==='question'||phase==='reveal'?track.options:[],audioUrl:track.ready?`/audio/${room.code}/${track.audioId}`:null,playAt:track.playAt||null,endAt:track.endAt||null,ready:!!track.ready,...(phase==='reveal'||phase==='finished'?{answer:BY_ID[track.id].area,title:BY_ID[track.id].title,extra:BY_ID[track.id].extra,trackNumber:track.id,answers:[...room.players.values()].map(p=>({id:p.id,name:p.name,guess:room.answers.get(p.id)||'',correct:correct(room.answers.get(p.id),BY_ID[track.id],room.settings.mode)}))}:{} )}:null,myAnswer:room.answers.get(viewer.id)||null,serverNow:Date.now()};}
function broadcast(room){room.touched=Date.now();for(const p of room.players.values())send(p.ws,{type:'state',state:publicState(room,p)});}
function error(ws,message){send(ws,{type:'error',message})}
function clearRoom(room){if(room.timer)clearTimeout(room.timer);if(room.currentTrack?.path)fsp.rm(room.currentTrack.path,{force:true}).catch(()=>{});rooms.delete(room.code);for(const p of room.players.values()){send(p.ws,{type:'room_closed'});if(p.ws){p.ws.roomCode=null;p.ws.playerId=null}}}
function requireHost(room,p,ws){if(room.hostId!==p.id){error(ws,'Only the host can do that.');return false}return true}
function invitePlayer(room,name,token,ws){if(room.phase!=='lobby'&&!token) return error(ws,'This game has already started. You can join the next match.');let player=token?[...room.players.values()].find(p=>p.token===token):null;
 if(!player){if(room.players.size>=MAX_PLAYERS)return error(ws,'That room is full (12 players maximum).');if(!name)return error(ws,'Enter your name to join.');if([...room.players.values()].some(p=>canonicalName(p.name)===canonicalName(name)))return error(ws,'That name is taken in this room.');player={id:randomId(),token:randomId(),name,score:0,ws:null};room.players.set(player.id,player)}
 if(player.ws&&player.ws!==ws){send(player.ws,{type:'replaced'});player.ws.close(1000,'Joined on another tab')}
 player.ws=ws;ws.roomCode=room.code;ws.playerId=player.id;send(ws,{type:'joined',code:room.code,token:player.token,playerId:player.id,isHost:player.id===room.hostId});broadcast(room);
 if(player.id===room.hostId&&room.phase==='loading'&&room.currentTrack&&!room.currentTrack.ready)send(ws,{type:'upload_required',trackId:room.currentTrack.id,roundIndex:room.roundIndex,audioId:room.currentTrack.audioId});
}
function readyForUpload(room){if(room.timer)clearTimeout(room.timer);const previous=room.currentTrack;room.phase='loading';room.answers.clear();room.roundIndex+=1;const id=room.queue[room.roundIndex],track=BY_ID[id];room.currentTrack={id,options:optionsFor(track),audioId:randomId(),ready:false,path:null,playAt:null,endAt:null};broadcast(room);for(const p of room.players.values())if(p.id===room.hostId)send(p.ws,{type:'upload_required',trackId:id,roundIndex:room.roundIndex,audioId:room.currentTrack.audioId});if(previous?.path)fsp.rm(previous.path,{force:true}).catch(()=>{});}
function beginRound(room){if(room.phase!=='loading'||!room.currentTrack?.ready)return;room.phase='question';room.currentTrack.playAt=Date.now()+1500;room.currentTrack.endAt=room.currentTrack.playAt+room.settings.duration*1000;broadcast(room);room.timer=setTimeout(()=>reveal(room),room.currentTrack.endAt-Date.now());}
function reveal(room){if(room.phase!=='question')return;clearTimeout(room.timer);room.timer=null;room.phase='reveal';const track=BY_ID[room.currentTrack.id];for(const p of room.players.values())if(correct(room.answers.get(p.id),track,room.settings.mode))p.score+=100;broadcast(room)}
function nextRound(room){if(room.phase!=='reveal')return;if(room.roundIndex+1>=room.queue.length){room.phase='finished';broadcast(room);return}readyForUpload(room)}
function onMessage(ws,msg){let d;try{d=JSON.parse(msg.toString('utf8'))}catch{return error(ws,'Invalid message')};if(!d||typeof d!=='object')return;
 if(d.type==='create'){if(ws.roomCode)return error(ws,'You are already in a room.');const name=cleanName(d.name);if(!name)return error(ws,'Enter your name first.');const code=uniqueCode();const room={code,hostId:null,players:new Map(),phase:'lobby',settings:validSettings(d.settings||{}),answers:new Map(),queue:[],roundIndex:-1,currentTrack:null,timer:null,touched:Date.now()};rooms.set(code,room);const player={id:randomId(),token:randomId(),name,score:0,ws:null};room.hostId=player.id;room.players.set(player.id,player);return invitePlayer(room,name,player.token,ws)}
 if(d.type==='join'){if(ws.roomCode)return error(ws,'You are already in a room.');const code=String(d.code||'').trim().toUpperCase();const room=rooms.get(code);if(!room)return error(ws,'Room not found. Double-check the code or ask the host for a new link.');return invitePlayer(room,cleanName(d.name),String(d.token||''),ws)}
 const room=rooms.get(ws.roomCode),player=room?.players.get(ws.playerId);if(!room||!player)return error(ws,'Please create or join a room first.');room.touched=Date.now();
 if(d.type==='settings'){if(!requireHost(room,player,ws)||room.phase!=='lobby')return;room.settings=validSettings(d.settings);broadcast(room)}
 else if(d.type==='start'){if(!requireHost(room,player,ws)||room.phase!=='lobby')return;const available=[...new Set((Array.isArray(d.trackIds)?d.trackIds:[]).filter(id=>typeof id==='string'&&BY_ID[id]))].filter(id=>{const t=BY_ID[id];return room.settings.pack==='all'||(room.settings.pack==='classic'&&+id<=70)||room.settings.pack===t.group});if(!available.length)return error(ws,'No imported BGM files match the selected map pack. Import songs or change the pack.');room.queue=randomize(available).slice(0,room.settings.rounds);room.roundIndex=-1;for(const p of room.players.values())p.score=0;return readyForUpload(room)}
 else if(d.type==='guess'){if(room.phase!=='question')return error(ws,'This round is not accepting guesses.');if(room.answers.has(player.id))return error(ws,'Your answer is already locked.');if(Date.now()>room.currentTrack.endAt+1000)return error(ws,'Time is up!');const guess=String(d.answer||'').trim().slice(0,80);if(!guess)return;if(room.settings.mode==='choice'&&!room.currentTrack.options.includes(guess))return error(ws,'Choose one of the available maps.');room.answers.set(player.id,guess);broadcast(room);if([...room.players.values()].filter(p=>p.ws?.readyState===WebSocket.OPEN).every(p=>room.answers.has(p.id)))reveal(room)}
 else if(d.type==='reveal'){if(!requireHost(room,player,ws))return;reveal(room)}
 else if(d.type==='next'){if(!requireHost(room,player,ws))return;nextRound(room)}
 else if(d.type==='rematch'){if(!requireHost(room,player,ws)||room.phase!=='finished')return;room.phase='lobby';room.queue=[];room.roundIndex=-1;room.answers.clear();if(room.currentTrack?.path)fsp.rm(room.currentTrack.path,{force:true}).catch(()=>{});room.currentTrack=null;for(const p of room.players.values())p.score=0;broadcast(room)}
 else if(d.type==='leave'){if(player.id===room.hostId){clearRoom(room);return}room.players.delete(player.id);ws.roomCode=null;ws.playerId=null;broadcast(room);if(room.phase==='question'&&[...room.players.values()].filter(p=>p.ws?.readyState===WebSocket.OPEN).every(p=>room.answers.has(p.id)))reveal(room)}
 else if(d.type==='kick'){if(!requireHost(room,player,ws)||room.phase!=='lobby')return;const target=room.players.get(d.targetId);if(target&&target.id!==player.id){send(target.ws,{type:'kicked'});if(target.ws){target.ws.roomCode=null;target.ws.playerId=null}room.players.delete(target.id);broadcast(room)}}
 else if(d.type==='close'){if(!requireHost(room,player,ws))return;clearRoom(room)}
 else if(d.type==='ping')send(ws,{type:'pong',serverNow:Date.now()});
}
function respond(res,status,body,type='application/json; charset=utf-8'){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(type.includes('json')?JSON.stringify(body):body)}
async function handleHttp(req,res){const url=new URL(req.url,'http://local');const pn=url.pathname;
 if(pn==='/health')return respond(res,200,{ok:true,rooms:rooms.size});
 if(pn==='/api/tracks'&&req.method==='GET')return respond(res,200,TRACKS);
 if(pn.startsWith('/api/rooms/')&&pn.endsWith('/audio')&&req.method==='PUT'){
  const code=pn.split('/')[3];const room=rooms.get(code),track=room?.currentTrack;const token=req.headers['x-host-token'];if(!room||room.phase!=='loading'||!track||![...room.players.values()].some(p=>p.id===room.hostId&&p.token===token))return respond(res,403,{error:'Not authorized to upload this track.'});
  const rawType=String(req.headers['content-type']||'');if(!/^(audio\/(mpeg|mp3|ogg|wav|x-wav|mp4|aac|flac|x-flac|m4a|x-m4a)|application\/octet-stream)/i.test(rawType))return respond(res,415,{error:'Please upload an audio file.'});
  const expected=Number(req.headers['content-length']||0);if(expected>MAX_UPLOAD)return respond(res,413,{error:'Audio file is too large (20 MB maximum).'});
  const audioPath=path.join(TEMP,`${room.code}-${track.audioId}.audio`);let bytes=0,tooLarge=false;const out=fs.createWriteStream(audioPath,{flags:'wx'});
  req.on('data',chunk=>{bytes+=chunk.length;if(bytes>MAX_UPLOAD&&!tooLarge){tooLarge=true;req.destroy()}});
  try{await pipeline(req,out);if(tooLarge)throw new Error('too big');if(room.phase!=='loading'||room.currentTrack!==track){await fsp.rm(audioPath,{force:true});return respond(res,409,{error:'Round changed while uploading.'})}track.path=audioPath;track.mime=rawType;track.ready=true;respond(res,200,{ok:true});beginRound(room)}catch(e){await fsp.rm(audioPath,{force:true}).catch(()=>{});if(!res.writableEnded&&!res.destroyed)respond(res,500,{error:'Audio upload failed. Try a smaller MP3 file.'})}return;
 }
 if(pn.startsWith('/audio/')&&req.method==='GET'){
  const [,_,code,audioId]=pn.split('/');const room=rooms.get(code),track=room?.currentTrack;if(!track||!track.ready||track.audioId!==audioId||!track.path)return respond(res,404,{error:'Audio no longer available'});
  try{const stat=await fsp.stat(track.path);const total=stat.size;let start=0,end=total-1,status=200;const range=req.headers.range;if(range){const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match){res.writeHead(416,{'Content-Range':`bytes */${total}`});return res.end()}start=match[1]?Number(match[1]):0;end=match[2]?Math.min(Number(match[2]),total-1):total-1;if(start> end||start>=total){res.writeHead(416,{'Content-Range':`bytes */${total}`});return res.end()}status=206}const headers={'Content-Type':track.mime||'audio/mpeg','Accept-Ranges':'bytes','Content-Length':end-start+1,'Cache-Control':'private, max-age=120','X-Content-Type-Options':'nosniff'};if(status===206)headers['Content-Range']=`bytes ${start}-${end}/${total}`;res.writeHead(status,headers);fs.createReadStream(track.path,{start,end}).on('error',()=>res.destroy()).pipe(res)}catch{respond(res,404,{error:'Audio file is unavailable'})}return;
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return respond(res,405,{error:'Method not allowed'});
 const pathname=pn==='/'?'/index.html':pn;const file=path.resolve(PUBLIC,'.'+pathname);if(!file.startsWith(PUBLIC+path.sep))return respond(res,403,{error:'Forbidden'});
 try{const stat=await fsp.stat(file);if(!stat.isFile())throw Error('not file');const ct=file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.svg')?'image/svg+xml':'application/octet-stream';res.writeHead(200,{'Content-Type':ct,'Content-Length':stat.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});if(req.method==='HEAD')res.end();else fs.createReadStream(file).pipe(res)}catch{respond(res,404,{error:'Page not found'})}
}
const server=http.createServer((req,res)=>{handleHttp(req,res).catch(err=>{console.error('Request error',err);if(!res.headersSent)respond(res,500,{error:'Server error'})})});
server.on('upgrade',(req,socket,head)=>{if(req.url!=='/socket'){socket.destroy();return}const key=req.headers['sec-websocket-key'];if(!key||req.headers.upgrade?.toLowerCase()!=='websocket'){socket.destroy();return}const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');const ws=new WebSocket(socket);if(head.length)ws.receive(head);ws.roomCode=null;ws.playerId=null;ws.on('message',data=>{try{onMessage(ws,data)}catch(err){console.error('WebSocket error',err);error(ws,'Something went wrong with your request.')}});ws.on('close',()=>{const room=rooms.get(ws.roomCode);const player=room?.players.get(ws.playerId);if(player&&player.ws===ws){player.ws=null;broadcast(room)}});ws.on('error',()=>{});send(ws,{type:'hello'})});
setInterval(()=>{const now=Date.now();for(const room of rooms.values()){const connected=[...room.players.values()].some(p=>p.ws?.readyState===WebSocket.OPEN);if((!connected&&now-room.touched>30*60_000)||now-room.touched>4*60*60_000)clearRoom(room)}},60_000).unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`Rune Recall online running on http://localhost:${PORT}`));
process.on('SIGTERM',()=>server.close());
