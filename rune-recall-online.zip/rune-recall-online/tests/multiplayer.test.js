const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { once } = require('node:events');
const port = 38970+Math.floor(Math.random()*1000);
const base = `http://127.0.0.1:${port}`;
let server;
async function waitForServer(){for(let i=0;i<80;i++){try{const r=await fetch(base+'/health');if(r.ok)return}catch{}await new Promise(resolve=>setTimeout(resolve,70))}throw Error('Server did not start')}
function connect(){return new Promise((resolve,reject)=>{const ws=new WebSocket(`ws://127.0.0.1:${port}/socket`);const inbox=[];const waiting=[];ws.addEventListener('message',event=>{const msg=JSON.parse(event.data);const idx=waiting.findIndex(w=>w.type===msg.type&&(w.predicate? w.predicate(msg):true));if(idx>=0){const [w]=waiting.splice(idx,1);clearTimeout(w.timeout);w.resolve(msg)}else inbox.push(msg)});ws.addEventListener('open',()=>resolve({ws,send(obj){ws.send(JSON.stringify(obj))},get(type,predicate){const idx=inbox.findIndex(m=>m.type===type&&(!predicate||predicate(m)));if(idx>=0)return Promise.resolve(inbox.splice(idx,1)[0]);return new Promise((resolve,reject)=>{const w={type,predicate,resolve,reject};w.timeout=setTimeout(()=>{const i=waiting.indexOf(w);if(i>=0)waiting.splice(i,1);reject(Error('Timed out waiting for '+type))},5000);waiting.push(w)})}}));ws.addEventListener('error',reject)})}
test.before(async()=>{server=spawn(process.execPath,['server.js'],{cwd:require('node:path').join(__dirname,'..'),env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});await waitForServer()});
test.after(()=>{server?.kill('SIGTERM')});
test('live rooms, invite codes, private answers, audio relay, scoring, rematches',async()=>{
 const host=await connect();const guest=await connect();
 await host.get('hello');await guest.get('hello');
 host.send({type:'create',name:'Host'});const joinA=await host.get('joined');assert.equal(joinA.code.length,6);let sA=(await host.get('state')).state;assert.equal(sA.players.length,1);assert.equal(sA.isHost,true);
 guest.send({type:'join',code:joinA.code,name:'Guest'});const joinB=await guest.get('joined');assert.equal(joinB.isHost,false);let sB=(await guest.get('state')).state;assert.equal(sB.players.length,2);assert.equal(sB.isHost,false);sA=(await host.get('state',m=>m.state.players.length===2)).state;
 guest.send({type:'settings',settings:{mode:'hard'}});const invalid=await guest.get('error');assert.match(invalid.message,/host/i);
 host.send({type:'settings',settings:{rounds:5,duration:30,pack:'classic',mode:'choice'}});sA=(await host.get('state',m=>m.state.settings.rounds===5)).state;sB=(await guest.get('state',m=>m.state.settings.rounds===5)).state;
 host.send({type:'start',trackIds:['08']});const loading=(await host.get('state',m=>m.state.phase==='loading')).state;assert.equal(loading.roundTotal,1);const upload=await host.get('upload_required');assert.equal(upload.trackId,'08');
 sB=(await guest.get('state',m=>m.state.phase==='loading')).state;assert.equal(sB.round?.answer,undefined);
 let r=await fetch(`${base}/api/rooms/${joinA.code}/audio`,{method:'PUT',headers:{'Content-Type':'audio/mpeg','X-Host-Token':'fake-token'},body:Buffer.from('fake')});assert.equal(r.status,403);
 r=await fetch(`${base}/api/rooms/${joinA.code}/audio`,{method:'PUT',headers:{'Content-Type':'audio/mpeg','X-Host-Token':joinA.token},body:Buffer.from('sample_mp3_bytes')});assert.equal(r.status,200);
 sA=(await host.get('state',m=>m.state.phase==='question')).state;sB=(await guest.get('state',m=>m.state.phase==='question')).state;
 assert.equal(sB.round.answer,undefined);assert.equal(sB.round.title,undefined);assert.equal(sA.round.options.length,4);assert.ok(sA.round.options.includes('Prontera'));
 r=await fetch(base+sB.round.audioUrl,{headers:{Range:'bytes=0-5'}});assert.equal(r.status,206);assert.equal((await r.arrayBuffer()).byteLength,6);
 host.send({type:'guess',answer:'Prontera'});sA=(await host.get('state',m=>m.state.players.find(p=>p.id===joinA.playerId)?.locked)).state;sB=(await guest.get('state',m=>m.state.players.find(p=>p.id===joinA.playerId)?.locked)).state;assert.equal(sB.round.answer,undefined);assert.equal(sB.players.find(p=>p.id===joinA.playerId).locked,true);assert.equal(sB.myAnswer,null);
 guest.send({type:'guess',answer:sB.round.options.find(x=>x!=='Prontera')});sA=(await host.get('state',m=>m.state.phase==='reveal')).state;sB=(await guest.get('state',m=>m.state.phase==='reveal')).state;assert.equal(sB.round.answer,'Prontera');assert.equal(sB.round.answers.length,2);assert.equal(sA.players.find(p=>p.id===joinA.playerId).score,100);assert.equal(sA.players.find(p=>p.id===joinB.playerId).score,0);
 host.send({type:'next'});sA=(await host.get('state',m=>m.state.phase==='finished')).state;assert.equal(sA.phase,'finished');
 host.send({type:'rematch'});sA=(await host.get('state',m=>m.state.phase==='lobby')).state;assert.equal(sA.players.find(p=>p.id===joinA.playerId).score,0);
 host.send({type:'close'});await guest.get('room_closed');host.ws.close();guest.ws.close();
});
